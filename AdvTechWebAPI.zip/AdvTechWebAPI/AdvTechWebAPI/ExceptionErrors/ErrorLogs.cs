﻿using AdvTechWebAPI.Extensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.ExceptionErrors
{
    #region Error logs
    public static class ErrorLogs
    {
        ///<summary>
        ///ExceptionE error log to the C: drive path
        ///</summary>
        public static void ErrorLogging(Exception ex)
        {
            var strPath = ConfigurationManager.AppSetting["LogFile:FilePath"];

            if (!File.Exists(strPath))
                File.Create(strPath).Dispose();

            using (StreamWriter sw = File.AppendText(strPath))
            {
                sw.WriteLine("=============Error Logging ===========");
                sw.WriteLine("===========Start============= " + DateTime.Now);
                sw.WriteLine("Error Message: " + ex.Message);
                sw.WriteLine("Stack Trace: " + ex.StackTrace);
                sw.WriteLine("===========End============= " + DateTime.Now);

            }
        }
    }
    #endregion
}
