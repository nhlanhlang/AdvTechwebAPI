﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Class
{
    public class ProgramRepositoryAPI : AuthenticationRepositoryAPI, IProgramRepositoryAPI
    {
        #region base URL

        string baseURL = ConfigurationManager.AppSetting["URL:BaseUrl"];

        #endregion
        public async Task<IEnumerable<ProgramModel>> GetProgramList(long academyId,long locationId, string bearerToken)
        {
            try
            {
                var programModelList = new List<ProgramModel>();
              
                using (var client = new HttpClient())
                {
                   
                    string getProgramList = ConfigurationManager.AppSetting["URL:GetProgramList"];
                    var urlParams = string.Format("{0}{1}{2}{3}{4}", getProgramList, "?academyId=", academyId, "&academyLocationId=", locationId);                  
                    var url = string.Format("{0}{1}", baseURL, urlParams);

                    client.BaseAddress = new Uri(baseURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);                  

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        programModelList = JsonConvert.DeserializeObject<List<ProgramModel>>(apiResponse.Result);
                    }
                    return programModelList;      
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<ProgramModel> GetProgram(long academyId, long locationId, string grade, string bearerToken)
        {
            try
            {
             
                var programList = await GetProgramList(academyId, locationId, bearerToken);
                var program = programList.FirstOrDefault(x => x.value == grade);

                return program;

            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }
}
