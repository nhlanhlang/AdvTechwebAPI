﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Repository.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Class
{
    public class AuthenticationRepositoryAPI : IAuthenticationRepositoryAPI
    {
        string baseURL = ConfigurationManager.AppSetting["URL:BaseUrl"];

        public async Task<AuthenticationModel> GetBearerToken(string clientId, string username, string password)
        {
            try
            {
                var clientModel = new ClientModel();
                var authenticationModel = new AuthenticationModel();

                using (var client = new HttpClient())
                {
                    var authorization =  ConfigurationManager.AppSetting["URL:Authorization"];
                    var url = string.Format("{0}{1}", baseURL, authorization);

                    clientModel.clientId = clientId;
                    clientModel.username = username;
                    clientModel.password = password;

                    var data = JsonConvert.SerializeObject(clientModel);

                    var content = new StringContent(data, UTF8Encoding.UTF8, "application/json");
                    var result =  client.PostAsync(url, content).Result;

                    if (result.IsSuccessStatusCode)
                    {
                        var apiResponse = result.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        authenticationModel = JsonConvert.DeserializeObject<AuthenticationModel>(apiResponse.Result);

                    }
                    return  authenticationModel;

                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        
    }
}
