﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using AdvTechWebAPI.ResponseAPI;
using System;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Class
{
    public class EmailRepositoryAPI : IEmailRepositoryAPI
    {
        public Response SendEnquiryEmail(EmailModel emailModel)
        {
            try
            {
                var result = new Response();
                using (MailMessage mail = new MailMessage())
                {
                    var emailFrom = ConfigurationManager.AppSetting["SMTPDetails:emailFrom"];
                    var emailTo = ConfigurationManager.AppSetting["SMTPDetails:emailTo"];
                    var emailCC = ConfigurationManager.AppSetting["SMTPDetails:ccEmail"];
                    var mailAddress = ConfigurationManager.AppSetting["SMTPDetails:address"];
                    var portNumber = ConfigurationManager.AppSetting["SMTPDetails:portNumber"];
                    var password = ConfigurationManager.AppSetting["SMTPDetails:password"];

                    mail.From = new MailAddress(emailFrom);                  
                    mail.To.Add(emailTo);
                    mail.CC.Add(emailCC);
                    mail.Subject = "New Lead: Partially Completed Enquiry";
                    mail.Body = "Good day <br/><br/>" +
                                 "This lead has partially completed the enquiry form on the website but did not submit the form. Kindly contact the lead and capture client details in STASY." +
                                 "<br/><br/>Please find their contact details below:" +
                                  "<br/>Name: " + emailModel.FirstName +" "+ emailModel.LastName +
                                 "<br/>Contact Number: " + emailModel.ContactNumber +
                                 "<br/>E-Mail Address: " + emailModel.Email +
                                 "<br/><br/>The lead has indicated they would like to be contacted.";


                    mail.IsBodyHtml = true;

                    using (SmtpClient smtp = new SmtpClient(mailAddress, int.Parse(portNumber)))
                    {
                        smtp.Credentials = new NetworkCredential(emailFrom, password);
                        smtp.EnableSsl = false;
                        smtp.Send(mail);
                        result.Code =  "201";
                        result.Message = "Successfully sent email";
                       
                    }
                    return  result;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }
}
