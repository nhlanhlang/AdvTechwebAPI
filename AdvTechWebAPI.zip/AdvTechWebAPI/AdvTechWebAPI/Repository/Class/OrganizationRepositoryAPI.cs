﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Class
{
    public class OrganizationRepositoryAPI : AuthenticationRepositoryAPI, IOrganizationRepositoryAPI
    {
        string baseURL = ConfigurationManager.AppSetting["URL:BaseUrl"];       

        public async Task<IEnumerable<AcademyModel>> GetAcademyList(string bearerToken)
        {
            try
            {
                var academyModel = new List<AcademyModel>();
                using (var client = new HttpClient())
                {
                    string academyListURL = ConfigurationManager.AppSetting["URL:GetAcademlyList"];
                    var url = string.Format("{0}{1}", baseURL, academyListURL);                   

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();
                       
                        academyModel = JsonConvert.DeserializeObject<List<AcademyModel>>(apiResponse.Result);
                    }
                    return academyModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<AcademyModel>> GetLocationList(string bearerToken,long academyId)
        {
            try
            {
                var academyModel = new List<AcademyModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetLocationList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);
                   
                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        academyModel = JsonConvert.DeserializeObject<List<AcademyModel>>(apiResponse.Result);
                    }
                    return academyModel.OrderBy(x => x.value);
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<MobileCodeModel>> GetMobileCodeList(string bearerToken)
        {
            try
            {
                var mobileModel = new List<MobileCodeModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetMobileCodeList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);
                   
                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        mobileModel = JsonConvert.DeserializeObject<List<MobileCodeModel>>(apiResponse.Result);
                    }
                    return mobileModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<AcademyModel>> GetSalutationList(string bearerToken)
        {
            try
            {
                var academyModel = new List<AcademyModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetSalutationList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        academyModel = JsonConvert.DeserializeObject<List<AcademyModel>>(apiResponse.Result);
                    }
                    return academyModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<AcademyModel>> GetSourceList(string bearerToken)
        {
            try
            {
                var academyModel = new List<AcademyModel>();
                using (var client = new HttpClient())
                {
                    string sourceListURL = ConfigurationManager.AppSetting["URL:GetSourceList"];
                    var url = string.Format("{0}{1}", baseURL, sourceListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        academyModel = JsonConvert.DeserializeObject<List<AcademyModel>>(apiResponse.Result);
                    }
                    return academyModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<MobileCodeModel>> GetYearOfCompletionList(string bearerToken)
        {
            try
            {
                var mobileModel = new List<MobileCodeModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetYearOfCompletionList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        mobileModel = JsonConvert.DeserializeObject<List<MobileCodeModel>>(apiResponse.Result);
                    }
                    return mobileModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<IntakeYearModel>> GetIntakeYearList(string bearerToken)
        {
            try
            {
                var intakeYearModel = new List<IntakeYearModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetIntakeYearList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        intakeYearModel = JsonConvert.DeserializeObject<List<IntakeYearModel>>(apiResponse.Result);
                    }
                    return intakeYearModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<GenderModel>> GetGenderList(string bearerToken)
        {
            try
            {
                var genderModel = new List<GenderModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetGenderList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        genderModel = JsonConvert.DeserializeObject<List<GenderModel>>(apiResponse.Result);
                    }
                    return genderModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<NationalityModel>> GetNationalityList(string bearerToken)
        {
            try
            {
                var nationalityModel = new List<NationalityModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetNationalityList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        nationalityModel = JsonConvert.DeserializeObject<List<NationalityModel>>(apiResponse.Result);
                    }
                    return nationalityModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<NationalityModel>> GetCountryList(string bearerToken)
        {
            try
            {
                var nationalityModel = new List<NationalityModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetCountryList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        nationalityModel = JsonConvert.DeserializeObject<List<NationalityModel>>(apiResponse.Result);
                    }
                    return nationalityModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<NationalityModel>> GetCountryRegion(string bearerToken, long countryId)
        {
            try
            {
                var academyModel = new List<NationalityModel>();
                using (var client = new HttpClient())
                {
                    string countryRegionURL = ConfigurationManager.AppSetting["URL:GetCountryRegion"];
                    var urlParams = string.Format("{0}{1}{2}", countryRegionURL, "?countryId=", countryId);
                    var url = string.Format("{0}{1}", baseURL, urlParams);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        academyModel = JsonConvert.DeserializeObject<List<NationalityModel>>(apiResponse.Result);
                    }
                    return academyModel.OrderBy(x => x.value);
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<DisabilityModel>> GetDisabilityList(string bearerToken)
        {
            try
            {
                var disabilityModel = new List<DisabilityModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetDisabilityList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        disabilityModel = JsonConvert.DeserializeObject<List<DisabilityModel>>(apiResponse.Result);
                    }
                    return disabilityModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<AcademyModel>> GetProgramCategoryList(string bearerToken)
        {
            try
            {
                var academyModel = new List<AcademyModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetProgramCategoryList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        academyModel = JsonConvert.DeserializeObject<List<AcademyModel>>(apiResponse.Result);
                    }
                    return academyModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<SchoolModel>> GetSchoolList(string bearerToken)
        {
            try
            {
                var schoolModel = new List<SchoolModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetSchoolList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        schoolModel = JsonConvert.DeserializeObject<List<SchoolModel>>(apiResponse.Result);
                    }
                    return schoolModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<ReligionModel>> GetReligionList(string bearerToken)
        {
            try
            {
                var religionModel = new List<ReligionModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetReligionList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        religionModel = JsonConvert.DeserializeObject<List<ReligionModel>>(apiResponse.Result);
                    }
                    return religionModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<CityModel>> GetCityList(string bearerToken, long countryId, long countryRegionId)
        {
            try
            {
                var cityModelList = new List<CityModel>();

                using (var client = new HttpClient())
                {

                    string getCityList = ConfigurationManager.AppSetting["URL:GetCityList"];
                    var urlParams = string.Format("{0}{1}{2}{3}{4}", getCityList, "?countryId=", countryId, "&countryRegionId=", countryRegionId);
                    var url = string.Format("{0}{1}", baseURL, urlParams);

                    client.BaseAddress = new Uri(baseURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        cityModelList = JsonConvert.DeserializeObject<List<CityModel>>(apiResponse.Result);
                    }
                    return cityModelList;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<IEnumerable<AcademyModel>> GetProgramCategoryByCampus(string bearerToken,long campusId)
        {
            var BedfordviewId = ConfigurationManager.AppSetting["CampusList:Bedfordview"];
            return null;
        }
    }
}
