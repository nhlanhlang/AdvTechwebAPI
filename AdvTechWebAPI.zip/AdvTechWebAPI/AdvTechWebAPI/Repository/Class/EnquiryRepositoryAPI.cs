﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using AdvTechWebAPI.ResponseAPI;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Class
{
    public class EnquiryRepositoryAPI : AuthenticationRepositoryAPI, IEnquiryRepositoryAPI
    {
        #region base URL

        string baseURL = ConfigurationManager.AppSetting["URL:BaseUrl"];

        #endregion
        public async Task<Response> CreateEnquiryByStudent(StudentModel studentModel, string bearerToken)
        {
            try
            {               
                using (var client = new HttpClient())
                {
                    var responseResult = new Response();
                    string createEnquiryByStudentURL = ConfigurationManager.AppSetting["URL:CreateEnquiryByStudent"];
                    var url = string.Format("{0}{1}", baseURL, createEnquiryByStudentURL);

                    client.BaseAddress = new Uri(baseURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var data = JsonConvert.SerializeObject(studentModel);
                    var content = new StringContent(data, UTF8Encoding.UTF8, "application/json");
                  
                    var response = await client.PostAsync(createEnquiryByStudentURL, content);
                    var stringData = await response.Content.ReadAsStringAsync();

                    responseResult = JsonConvert.DeserializeObject<Response>(stringData);
                    responseResult.Message = stringData;

                    return responseResult;
                }

            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<IEnumerable<AcademyModel>> GetEnquiryModeList(string bearerToken)
        {
            try
            {
                var academyModelList = new List<AcademyModel>();
                using (var client = new HttpClient())
                {
                    string locationListURL = ConfigurationManager.AppSetting["URL:GetEnquiryModeList"];
                    var url = string.Format("{0}{1}", baseURL, locationListURL);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        academyModelList = JsonConvert.DeserializeObject<List<AcademyModel>>(apiResponse.Result);
                    }
                    return academyModelList;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<EnquiryModel> GetEnquiryByEnquiryId(string bearerToken, string enquirerEmail, string enquiryCode)
        {
            try
            {
                var enquiryModel = new EnquiryModel();
                using (var client = new HttpClient())
                {
                    string enquityModelURL = ConfigurationManager.AppSetting["URL:GetEnquiryByEnquiryId"];
                    var urlParams = string.Format("{0}{1}{2}{3}{4}", enquityModelURL, "?enquirerEmail=", enquirerEmail, "&enquiryCode=", enquiryCode);                  
                    var url = string.Format("{0}{1}", baseURL, urlParams);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        enquiryModel = JsonConvert.DeserializeObject<EnquiryModel>(apiResponse.Result);
                    }
                    return enquiryModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }
}
