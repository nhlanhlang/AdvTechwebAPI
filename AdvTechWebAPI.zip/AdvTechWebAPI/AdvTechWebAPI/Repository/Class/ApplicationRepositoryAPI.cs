﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using AdvTechWebAPI.ResponseAPI;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Class
{
    public class ApplicationRepositoryAPI : AuthenticationRepositoryAPI, IApplicationRepositoryAPI
    {
        #region base URL

        string baseURL = ConfigurationManager.AppSetting["URL:BaseUrl"];

        #endregion
        public async Task<Response> CreateNewApplication(NewApplicationModel applicationModel, string bearerToken)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var responseResult = new Response();
                    string createEnquiryByStudentURL = ConfigurationManager.AppSetting["URL:CreateNewApplication"];
                    var url = string.Format("{0}{1}", baseURL, createEnquiryByStudentURL);

                    client.BaseAddress = new Uri(baseURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var data = JsonConvert.SerializeObject(applicationModel);
                    var content = new StringContent(data, UTF8Encoding.UTF8, "application/json");

                    var response = await client.PostAsync(createEnquiryByStudentURL, content);
                    var stringData = await response.Content.ReadAsStringAsync();

                    responseResult = JsonConvert.DeserializeObject<Response>(stringData);
                    responseResult.Message = stringData;

                    return responseResult;
                }

            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        public async Task<ApplicationModel> GetApplicationByApplicationId(string bearerToken, string applicationCodes)
        {
            try
            {
                var applicationModel = new ApplicationModel();
                using (var client = new HttpClient())
                {
                    string applicationModelURL = ConfigurationManager.AppSetting["URL:GetApplicationByApplicationId"];
                    var urlParams = string.Format("{0}{1}{2}", applicationModelURL, "?applicationCodes=", applicationCodes);
                    var url = string.Format("{0}{1}", baseURL, urlParams);

                    client.BaseAddress = new Uri(url);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var responseMessage = client.GetAsync(url);
                    responseMessage.Wait();
                    var taskResult = responseMessage.Result;
                    if (taskResult.IsSuccessStatusCode)
                    {
                        var apiResponse = taskResult.Content.ReadAsStringAsync();
                        apiResponse.Wait();

                        applicationModel = JsonConvert.DeserializeObject<ApplicationModel>(apiResponse.Result);
                    }
                    return applicationModel;
                }
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        public async Task<Response> UploadApplicationDocument(DocumentsModel documentModel, string bearerToken)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var responseResult = new Response();
                    string uploadApplicationDocumentsURL = ConfigurationManager.AppSetting["URL:UploadApplicationDocuments"];
                    var url = string.Format("{0}{1}", baseURL, uploadApplicationDocumentsURL);

                    client.BaseAddress = new Uri(baseURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", bearerToken);

                    var data = JsonConvert.SerializeObject(documentModel);
                    var content = new StringContent(data, UTF8Encoding.UTF8, "application/json");

                    var response = await client.PostAsync(uploadApplicationDocumentsURL, content);
                    var stringData = await response.Content.ReadAsStringAsync();

                    responseResult = JsonConvert.DeserializeObject<Response>(stringData);
                    responseResult.Message = stringData;

                    return responseResult;
                }

            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }
}
