﻿using AdvTechWebAPI.Models;
using AdvTechWebAPI.ResponseAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Interface
{
    public interface IApplicationRepositoryAPI : IAuthenticationRepositoryAPI
    {
        Task<Response> CreateNewApplication(NewApplicationModel applicationModel, string bearerToken);

        Task<ApplicationModel> GetApplicationByApplicationId(string bearerToken, string applicationCodes);

        Task<Response> UploadApplicationDocument(DocumentsModel documentModel, string bearerToken);
    }
}
