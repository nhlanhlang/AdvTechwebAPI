﻿using AdvTechWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Interface
{
    public interface IProgramRepositoryAPI : IAuthenticationRepositoryAPI
    {
        Task<IEnumerable<ProgramModel>> GetProgramList(long academyId, long locationId, string bearerToken);

        Task<ProgramModel> GetProgram(long academyId, long locationId, string grade, string bearerToken);
    }
}
