﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Interface
{
    public interface IAuthenticationRepositoryAPI
    {
        Task<AuthenticationModel> GetBearerToken(string clientId, string username, string password);
    }
}
