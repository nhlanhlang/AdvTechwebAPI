﻿using AdvTechWebAPI.Models;
using AdvTechWebAPI.ResponseAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Interface
{
    public interface IPaymentRepositoryAPI : IAuthenticationRepositoryAPI
    {
        Task<Response> CreateStudentPayment(PaymentModel paymentModel, string bearerToken);
    }
}
