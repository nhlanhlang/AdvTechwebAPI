﻿using AdvTechWebAPI.Models;
using AdvTechWebAPI.ResponseAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Interface
{
    public interface IEnquiryRepositoryAPI : IAuthenticationRepositoryAPI
    {
        Task<Response> CreateEnquiryByStudent(StudentModel student, string bearerToken);

        Task<IEnumerable<AcademyModel>> GetEnquiryModeList(string bearerToken);

        Task<EnquiryModel> GetEnquiryByEnquiryId(string bearerToken, string enquirerEmail, string enquiryCode);
    }
}
