﻿using AdvTechWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Repository.Interface
{
    public interface IOrganizationRepositoryAPI : IAuthenticationRepositoryAPI
    {
        Task<IEnumerable<AcademyModel>> GetAcademyList(string authorizationToken);

        Task<IEnumerable<AcademyModel>> GetLocationList(string bearerToken, long academyId);

        Task<IEnumerable<MobileCodeModel>> GetMobileCodeList(string bearerToken);

        Task<IEnumerable<AcademyModel>> GetSalutationList(string bearerToken);

        Task<IEnumerable<AcademyModel>> GetSourceList(string bearerToken);

        Task<IEnumerable<MobileCodeModel>> GetYearOfCompletionList(string bearerToken);

        Task<IEnumerable<IntakeYearModel>> GetIntakeYearList(string bearerToken);

        Task<IEnumerable<GenderModel>> GetGenderList(string bearerToken);

        Task<IEnumerable<NationalityModel>> GetNationalityList(string bearerToken);

        Task<IEnumerable<NationalityModel>> GetCountryList(string bearerToken);

        Task<IEnumerable<AcademyModel>> GetProgramCategoryList(string bearerToken);

        Task<IEnumerable<AcademyModel>> GetProgramCategoryByCampus(string bearerToken,long campusId);

        Task<IEnumerable<DisabilityModel>> GetDisabilityList(string bearerToken);

        Task<IEnumerable<SchoolModel>> GetSchoolList(string bearerToken);

        Task<IEnumerable<ReligionModel>> GetReligionList(string bearerToken);      

        Task<IEnumerable<CityModel>> GetCityList(string bearerToken, long countryId, long countryRegionId);

        Task<IEnumerable<NationalityModel>> GetCountryRegion(string bearerToken, long countryId);
    }
}
