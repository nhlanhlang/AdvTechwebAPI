﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Models
{
    public class MobileCodeModel
    {
        public string code { get; set; }
    }
}
