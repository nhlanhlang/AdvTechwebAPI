﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Models
{
    public class DisabilityModel
    {
        public long id { get; set; }

        public string code { get; set; }

        public string value { get; set; }
    }
}
