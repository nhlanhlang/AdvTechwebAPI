﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Models
{
    public class ProgramModel
    {
      public long  id { get; set; }
      public string code { get; set; }
      public string value { get; set; }        
      public long programCategoryId { get; set; }
      public string programCategoryName { get; set; }
      public long departmentId { get; set; }
      public string departmentName { get; set; }
      public long academyLocationId { get; set; }
      public string academyLocationName { get; set; }
      public long academyId { get; set; }
      public string academyName { get; set; }
      public long locationId { get; set; }
      public string locationName { get; set; }
      public long programGroupId { get; set; }
      public string programGroupName { get; set; }
      public string comment { get; set; }
   
    }
}
