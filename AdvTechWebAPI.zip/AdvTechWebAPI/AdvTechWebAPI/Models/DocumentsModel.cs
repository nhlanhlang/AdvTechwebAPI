﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Models
{
    public class DocumentsModel
    {
        public string documentCode { get; set; }

        [Required]
        public string documentBase64String { get; set; }

        [Required]
        public string documentFileName { get; set; }

        public string isMandatoryDocument { get; set; }

        public string documentLabel { get; set; }


    }
}
