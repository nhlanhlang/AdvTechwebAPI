﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Models
{
    public class ApplicationModel
    {
       
        [Required]
        public string applicationCode { get; set; }

        [Required]
        public long academyId { get; set; }

        [Required]
        public long locationId { get; set; }

        [Required]
        public long intakeYearId { get; set; }

        [Required]
        public long modeOfDeliveryId { get; set; }

        [Required]
        public bool isBatchPartTime { get; set; }

        [Required]
        public long programId { get; set; }

        [Required]
        public long studentSalutationId { get; set; }

        [Required]
        public string studentFirstName { get; set; }

        public string studentMiddleName { get; set; }

        [Required]
        public string studentSurname { get; set; }

        [Required]
        public string studentEmail { get; set; }

        [Required]
        public string studentMobileCountryCode { get; set; }

        [Required]
        public string studentMobileNo { get; set; }

        public string studentAlternateCountryCode { get; set; }

        public string studentAlternateNo { get; set; }

        public string address { get; set; }

        public long? countryId { get; set; }

        public long? countryRegionId { get; set; }

        public long? cityId { get; set; }

        public string suburb { get; set; }

        public string pincode { get; set; }

        public string disabilityIds { get; set; }

        public bool isStudentCitizen { get; set; }

        public bool? isPermanentResident { get; set; }

        public bool? isAsylumSeeker { get; set; }

        [Required]
        public string nationalId { get; set; }

        [Required]
        public long? nationalityId { get; set; }

        [Required]
        public long? castCategoryId { get; set; }

        [Required]
        public string birthDate { get; set; }

        [Required]
        public long? genderId { get; set; }

        [Required]
        public string enquiryModeIds { get; set; }

        public string comment { get; set; }

        public long fatherSalutationId { get; set; }

        public string fatherFirstName { get; set; }

        public string fatherSurname { get; set; }

        public string fatherEmail { get; set; }

        public string fatherMobileCountryCode { get; set; }

        public string fatherMobileNo { get; set; }

        public string fatherAlternateCountryCode { get; set; }

        public string fatherAlternateNo { get; set; }

        public bool isSponsored { get; set; }

        public string sponsoredName { get; set; }

        public long? examPassedId { get; set; }

        public string examPassedOther { get; set; }

        public long? yearOfExamination { get; set; }

        public string instituteName { get; set; }

        public long sourceId { get; set; }

        public long userId { get; set; }

        public bool isHostelRequried { get; set; }
    }
}
