﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Models
{
    public class PaymentModel
    {
        public string instrumentDate { get; set; }

        public string instrumentNumber { get; set; }

        [Required]
        public string paymentMode { get; set; }

        [Required]
        public string paymentVoucherNumber { get; set; }

        [Required]
        public string paymentFor { get; set; }

        [Required]
        public string paymentTo { get; set; }

        [Required]
        public string payingIAU { get; set; }

        [Required]
        public string paymentCurrency { get; set; }

        [Required]
        public string paymentDate { get; set; }

        [Required]
        public string studentApplicantCode { get; set; }

        [Required]
        public string instrumentPaymentModeName { get; set; }

        [Required]
        public string instrumentBankCode { get; set; }

        [Required]
        public decimal amount { get; set; }

        [Required]
        public string narration { get; set; }

        [Required]
        public string creditNoteNumbers { get; set; }




    }
}
