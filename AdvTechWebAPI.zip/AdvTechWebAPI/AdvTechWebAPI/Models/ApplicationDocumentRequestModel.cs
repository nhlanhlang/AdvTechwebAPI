﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Models
{
    public class ApplicationDocumentRequestModel
    {
        public string applicationCode { get; set; }

        public List<DocumentsModel> DocumentsModels { get; set; }
    }
}
