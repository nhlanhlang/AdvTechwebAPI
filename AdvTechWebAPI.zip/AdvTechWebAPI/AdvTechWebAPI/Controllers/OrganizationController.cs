﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Repository.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizationController : ControllerBase
    {
        #region Authorization

        string clientId = ConfigurationManager.AppSetting["Authorization:clientId"];
        string username = ConfigurationManager.AppSetting["Authorization:username"];
        string password = ConfigurationManager.AppSetting["Authorization:password"];

        #endregion

        #region Repository

        private readonly IOrganizationRepositoryAPI organizationRepository;
      
        #endregion

        public OrganizationController(IOrganizationRepositoryAPI _organizationRepository)
        {
            organizationRepository = _organizationRepository;
           
        }
        
        [HttpGet("GetAcademyList")]
        public async Task<IActionResult> GetAcademyList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var academyList = await organizationRepository.GetAcademyList(authorization.access_token);
                    if (academyList == null)
                        return NotFound();

                    return Ok(academyList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetLocationList")]
        public async Task<IActionResult> GetLocationList(long academyId)
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var locationList = await organizationRepository.GetLocationList(authorization.access_token, academyId);
                    if (locationList == null)
                        return NotFound();

                    return Ok(locationList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetMobileCountryCodeList")]
        public async Task<IActionResult> GetMobileCountryCodeList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var mobileCountryCode = await organizationRepository.GetMobileCodeList(authorization.access_token);
                    if (mobileCountryCode == null)
                        return NotFound();

                    return Ok(mobileCountryCode);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetYearOfCompletionList")]
        public async Task<IActionResult> GetYearOfCompletionList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var yearOfCompletion = await organizationRepository.GetYearOfCompletionList(authorization.access_token);
                    if (yearOfCompletion == null)
                        return NotFound();

                    return Ok(yearOfCompletion);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetGenderList")]
        public async Task<IActionResult> GetGenderList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var genderList = await organizationRepository.GetGenderList(authorization.access_token);
                    if (genderList == null)
                        return NotFound();

                    return Ok(genderList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetNationalityList")]
        public async Task<IActionResult> GetNationalityList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var nationalityList = await organizationRepository.GetNationalityList(authorization.access_token);
                    if (nationalityList == null)
                        return NotFound();

                    return Ok(nationalityList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetCountryList")]
        public async Task<IActionResult> GetCountryList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var nationalityList = await organizationRepository.GetCountryList(authorization.access_token);
                    if (nationalityList == null)
                        return NotFound();

                    return Ok(nationalityList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetSchoolList")]
        public async Task<IActionResult> GetSchoolList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var schoolList = await organizationRepository.GetSchoolList(authorization.access_token);
                    if (schoolList == null)
                        return NotFound();

                    return Ok(schoolList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetDisabilityList")]
        public async Task<IActionResult> GetDisabilityList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var disabilityList = await organizationRepository.GetDisabilityList(authorization.access_token);
                    if (disabilityList == null)
                        return NotFound();

                    return Ok(disabilityList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetReligionList")]
        public async Task<IActionResult> GetReligionList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var religionList = await organizationRepository.GetReligionList(authorization.access_token);
                    if (religionList == null)
                        return NotFound();

                    return Ok(religionList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetCityList/{countryId}/{countryRegionId}")]
        public async Task<IActionResult> GetCityList(long countryId, long countryRegionId)
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var cityList = await organizationRepository.GetCityList(authorization.access_token,countryId, countryRegionId);
                    if (cityList == null)
                        return NotFound();

                    return Ok(cityList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetCountryRegion/{countryId}")]
        public async Task<IActionResult> GetCountryRegion(long countryId)
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var cityList = await organizationRepository.GetCountryRegion(authorization.access_token, countryId);
                    if (cityList == null)
                        return NotFound();

                    return Ok(cityList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetSalutationList")]
        public async Task<IActionResult> GetSalutationList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var salutationList = await organizationRepository.GetSalutationList(authorization.access_token);
                    if (salutationList == null)
                        return NotFound();

                    return Ok(salutationList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetSourceList")]
        public async Task<IActionResult> GetSourceList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var sourceList = await organizationRepository.GetSourceList(authorization.access_token);
                    if (sourceList == null)
                        return NotFound();

                    return Ok(sourceList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetIntakeYearList")]
        public async Task<IActionResult> GetIntakeYearList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var getIntakeYearList = await organizationRepository.GetIntakeYearList(authorization.access_token);
                    if (getIntakeYearList == null)
                        return NotFound();

                    return Ok(getIntakeYearList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetProgramCategoryList")]
        public async Task<IActionResult> GetProgramCategoryList()
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var getIntakeYearList = await organizationRepository.GetProgramCategoryList(authorization.access_token);
                    if (getIntakeYearList == null)
                        return NotFound();

                    return Ok(getIntakeYearList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

       
        [HttpGet("GetProgramCategoryByCampus/{academyId}")]
        public async Task<IActionResult> GetProgramCategoryByCampus(long academyId)
        {
            try
            {
                var authorization = await organizationRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var categoryCampus = await organizationRepository.GetProgramCategoryByCampus(authorization.access_token, academyId);
                    if (categoryCampus == null)
                        return NotFound();

                    return Ok(categoryCampus);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }

   
}
