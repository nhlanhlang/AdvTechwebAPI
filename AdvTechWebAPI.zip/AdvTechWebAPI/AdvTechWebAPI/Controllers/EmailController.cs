﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using AdvTechWebAPI.ResponseAPI;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        #region Repository

        private readonly IEmailRepositoryAPI emailRepository;

        #endregion

        #region Constructor
        public EmailController(IEmailRepositoryAPI _emailRepository)
        {
            emailRepository = _emailRepository;

        }

        #endregion

        #region Send enquiry student email
        /// <summary>
        ///Create enquiry student
        /// </summary>
        /// <param name="firstName">firstName</param>    
        /// <param name="lastName">lastName</param>    
        /// <param name="emailAddress">emailAddress</param>  
        /// <param name="contactNumber">contactNumberl</param>        
        /// <returns>Response with success or failed message</returns>
        [HttpPost("SendEnquiryStudentEmail")]
        [Produces("application/json")]
        public async Task<ActionResult<Response>> SendEnquiryStudentEmail([FromBody] EmailModel emailModel)
        {
            try
            {
                var response = new Response();
                if (emailModel.FirstName != "string" &&
                     emailModel.LastName != "string")
                    response = emailRepository.SendEnquityEmail(emailModel);
                else
                    response.Message = "please enter all the required email details.";

                return response;
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        #endregion
    }
}
