﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using AdvTechWebAPI.ResponseAPI;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AdvTechWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        #region Authorization

        string clientId = ConfigurationManager.AppSetting["Authorization:clientId"];
        string username = ConfigurationManager.AppSetting["Authorization:username"];
        string password = ConfigurationManager.AppSetting["Authorization:password"];

        #endregion

        #region Repository

        private readonly IPaymentRepositoryAPI paymentRepository;

        #endregion

        #region Constructor
        public PaymentController(IPaymentRepositoryAPI _paymentRepository)
        {
            paymentRepository = _paymentRepository;

        }

        #endregion

        #region Create student payment
        /// <summary>
        ///Create enquiry student
        /// </summary>
        /// <param name="paymentModel">paymentModel</param>        
        /// <returns>Response with success or failed message</returns>
        [HttpPost("CreateStudentPayment")]
        public async Task<ActionResult<Response>> CreateStudentPayment(PaymentModel paymentModel)
        {
            try
            {
                var response = new Response();
                var authorization = await paymentRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                    response = await paymentRepository.CreateStudentPayment(paymentModel, authorization.access_token);

                return response;
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        #endregion
    }
}
