﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Models;
using AdvTechWebAPI.Repository.Interface;
using AdvTechWebAPI.ResponseAPI;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnquiryController : ControllerBase
    {
        #region Authorization

        string clientId = ConfigurationManager.AppSetting["Authorization:clientId"];
        string username = ConfigurationManager.AppSetting["Authorization:username"];
        string password = ConfigurationManager.AppSetting["Authorization:password"];

        #endregion

        #region Repository

        private readonly IEnquiryRepositoryAPI enquiryRepository;

        #endregion

        #region Constructor
        public EnquiryController(IEnquiryRepositoryAPI _enquiryRepository)
        {
            enquiryRepository = _enquiryRepository;
        }

        #endregion

        #region Create enquiry student
        /// <summary>
        ///Create enquiry student
        /// </summary>
        /// <param name="studentModel">studentModel</param>        
        /// <returns>Response with success or failed message</returns>
        [HttpPost("CreateEnquiryByStudent")]
        public async Task<ActionResult<Response>> CreateEnquiryByStudent(StudentModel studentModel)
        {
            try
            {
                var response = new Response();
                var authorization = await enquiryRepository.GetBearerToken(clientId, username, password);               

                if (authorization != null)                
                    response = await enquiryRepository.CreateEnquiryByStudent(studentModel, authorization.access_token);

                return response;
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
        #endregion

        [HttpGet("GetEnquiryModeList")]
        public async Task<IActionResult> GetEnquiryModeList()
        {
            try
            {
                var authorization = await enquiryRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var getIntakeYearList = await enquiryRepository.GetEnquiryModeList(authorization.access_token);
                    if (getIntakeYearList == null)
                        return NotFound();

                    return Ok(getIntakeYearList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetEnquiryByEnquiryId/{email}/{enquiryCode}")]       
        public async Task<IActionResult> GetEnquiryByEnquiryId(string email, string enquiryCode)
        {
            try
            {
                var authorization = await enquiryRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var enquiry = await enquiryRepository.GetEnquiryByEnquiryId(authorization.access_token,email,enquiryCode);
                    if (enquiry == null)
                        return NotFound();

                    return Ok(enquiry);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }
}
