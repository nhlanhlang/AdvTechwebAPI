﻿using AdvTechWebAPI.ExceptionErrors;
using AdvTechWebAPI.Extensions;
using AdvTechWebAPI.Repository.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProgramController : ControllerBase
    {
        #region Authorization

        string clientId = ConfigurationManager.AppSetting["Authorization:clientId"];
        string username = ConfigurationManager.AppSetting["Authorization:username"];
        string password = ConfigurationManager.AppSetting["Authorization:password"];

        #endregion

        #region Repository

        private readonly IProgramRepositoryAPI programRepository;

        #endregion

        public ProgramController(IProgramRepositoryAPI _programRepository)
        {
            programRepository = _programRepository;

        }
      
        [HttpGet("GetProgramList/{academyId}/{locationId}")]
        public async Task<IActionResult> GetProgramList(long academyId, long locationId)
        {
            try
            {
                var authorization = await programRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var academyList = await programRepository.GetProgramList(academyId,locationId, authorization.access_token);
                    if (academyList == null)
                        return NotFound();

                    return Ok(academyList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }

        [HttpGet("GetProgram/{academyId}/{locationId}/{grade}")]
        public async Task<IActionResult> GetProgram(long academyId, long locationId, string grade)
        {
            try
            {
                var authorization = await programRepository.GetBearerToken(clientId, username, password);

                if (authorization != null)
                {
                    var academyList = await programRepository.GetProgram(academyId, locationId, grade, authorization.access_token);
                    if (academyList == null)
                        return NotFound();

                    return Ok(academyList);
                }
                return NotFound();
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }
}
