﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using AdvTechWebAPI.Extensions;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Text;
using AdvTechWebAPI.Repository.Interface;
using AdvTechWebAPI.ExceptionErrors;

namespace AdvTechWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {

        #region Repository

        private readonly IAuthenticationRepositoryAPI repository;

        #endregion
     
        public AuthenticationController(IAuthenticationRepositoryAPI _repository)
        {
            repository = _repository;
        }


        [HttpGet("{clientId}/{username}/{password}")]      
        public async Task<ActionResult<AuthenticationModel>> GetBearerToken(string clientId, string username, string password)
        {
            try
            {
                var model = await repository.GetBearerToken(clientId, username, password);
                return model;
                
            }
            catch (Exception ex)
            {
                ErrorLogs.ErrorLogging(ex);
                throw;
            }
        }
    }
}
