﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdvTechWebAPI.Extensions
{
    #region Constants Class
    /// <summary>
    /// Indicates the result statuses
    /// </summary>
    public static class Constants
    {
        public const string FAILED_STATUS = "Failed";
        public const string SUCCESS_STATUS = "Success";

        public const string SUCCESS_MESSAGE = "Successfully saved/updated details";
        public const string FAILED_MESSAGE = "Failed save/update details";
       
    }

    #endregion
}
